java -jar target/spring-petclinic-2.1.0.BUILD-SNAPSHOT.jar
